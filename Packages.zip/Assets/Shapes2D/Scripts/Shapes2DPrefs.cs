﻿using UnityEngine;

public class Shapes2DPrefs : ScriptableObject {

	public float pixelsPerUnit = 100;

}
