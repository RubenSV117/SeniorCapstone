Shapes2D documentation is at https://sub-c.org/Shapes2D/documentation/.

Thanks for using Shapes2D!